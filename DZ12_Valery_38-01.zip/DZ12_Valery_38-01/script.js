
let name = "vALERY";
let surname = "kHaRcHeNkO";
function capitalize (name, surname) {
  return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase() + " " + surname.charAt(0).toUpperCase() + surname.substring(1).toLowerCase();
};
console.log(capitalize(name,surname));
// -----------------------------------------------------------------------------------------------------------------
let word = "Parallelogram";
function charCount(word) {
    return word.split("m").length - 1;
  }
console.log("Parallelogram 'm'" + " " + "is" + " " + charCount(word));